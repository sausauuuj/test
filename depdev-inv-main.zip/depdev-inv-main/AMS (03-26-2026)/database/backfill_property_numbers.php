<?php
declare(strict_types=1);

require_once __DIR__ . '/../bootstrap.php';

use App\Core\Database;
$connection = Database::connection();

$typeCodes = [
    'Computer Software' => 'CS',
    'Fixed Asset' => 'FA',
    'Furniture and Fixtures' => 'FF',
    'ICT Equipment' => 'ICT',
    'Medicine Inventory' => 'MI',
    'Motor Vehicle' => 'MV',
    'Office Equipment' => 'OE',
];

$buildTypeCode = static function (string $propertyType) use ($typeCodes): string {
    if (isset($typeCodes[$propertyType])) {
        return $typeCodes[$propertyType];
    }

    $words = preg_split('/[^A-Z0-9]+/', strtoupper($propertyType), -1, PREG_SPLIT_NO_EMPTY) ?: [];
    $acronym = implode('', array_map(
        static fn (string $word): string => substr($word, 0, 1),
        array_slice($words, 0, 3)
    ));

    return $acronym !== '' ? $acronym : 'GEN';
};

$buildNameCode = static function (string $propertyName): string {
    $words = preg_split('/[^A-Z0-9]+/', strtoupper($propertyName), -1, PREG_SPLIT_NO_EMPTY) ?: [];

    if (count($words) >= 2) {
        return implode('', array_map(
            static fn (string $word): string => substr($word, 0, 1),
            array_slice($words, 0, 3)
        ));
    }

    if ($words !== []) {
        return substr($words[0], 0, min(strlen($words[0]), 4));
    }

    return 'ITEM';
};

$prefixSequences = [];
$existingPropertyNumbers = $connection->query(
    "SELECT property_number
     FROM assets
     WHERE property_number IS NOT NULL
       AND property_number <> ''"
)->fetchAll(PDO::FETCH_COLUMN);

foreach ($existingPropertyNumbers as $propertyNumber) {
    if (preg_match('/^(.*)-\[(\d+)\]$/', (string) $propertyNumber, $matches) !== 1) {
        continue;
    }

    $prefix = (string) $matches[1];
    $sequence = (int) $matches[2];
    $prefixSequences[$prefix] = max((int) ($prefixSequences[$prefix] ?? 0), $sequence);
}

$assets = $connection->query(
    "SELECT id, property_name, property_type, classification
     FROM assets
     WHERE property_number IS NULL
        OR property_number = ''
     ORDER BY id ASC"
)->fetchAll(PDO::FETCH_ASSOC);

$updateStatement = $connection->prepare(
    'UPDATE assets
     SET property_number = :property_number
     WHERE id = :id'
);

$updatedRows = 0;

try {
    $connection->beginTransaction();

    foreach ($assets as $asset) {
        $classification = strtoupper(trim((string) ($asset['classification'] ?? '')));
        $typeCode = $buildTypeCode((string) ($asset['property_type'] ?? ''));
        $prefix = $classification === 'PPE'
            ? $typeCode . '-' . $buildNameCode((string) ($asset['property_name'] ?? ''))
            : 'SEMI-' . $typeCode;

        $nextSequence = ((int) ($prefixSequences[$prefix] ?? 0)) + 1;
        $prefixSequences[$prefix] = $nextSequence;

        $propertyNumber = sprintf('%s-[%03d]', $prefix, $nextSequence);

        $updateStatement->execute([
            'property_number' => $propertyNumber,
            'id' => (int) $asset['id'],
        ]);

        $updatedRows++;
        echo sprintf("Asset #%d => %s\n", (int) $asset['id'], $propertyNumber);
    }

    $connection->commit();
    echo sprintf("Updated %d asset row(s).\n", $updatedRows);
} catch (Throwable $throwable) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    fwrite(STDERR, 'Backfill failed: ' . $throwable->getMessage() . PHP_EOL);
    exit(1);
}
